from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Employees, Student


# Create your forms here.

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)

	class Meta:
		model = User
		fields = ("username", "email", "password1", "password2")

	def save(self, commit=True):
		user = super(NewUserForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		if commit:
			user.save()
		return user

class NewEmployeeForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    employee_code = forms.CharField(required=True)
    first_name = forms.CharField(required=True)
    dept_name = forms.CharField(required=True)
    class Meta:
        model = Employees
        fields = ("first_name","last_name", "email", "employee_code", "dept_name")

    def save(self, commit=True):
        employee = super(NewEmployeeForm, self).save(commit=False)
        employee.email = self.cleaned_data['email']
        if commit:
            employee.save()
        return employee

class EmployeesListForm(forms.ModelForm):
    class Meta:
        model = Employees
        fields = '__all__'

class NewStudentForm(forms.ModelForm):

    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    registration_number = forms.CharField(required=True)

    class Meta:
        model = Student
        fields = "__all__"

    def save(self, commit=True):
        student = super(NewStudentForm, self).save(commit=False)
        if commit:
            student.save()
        return student

